#pragma once
#define SECRET_AP_PASSWORD "redled123"
#define SECRET_PANEL_PASSWORD "redled123"
#define SECRET_OTA_PASSWORD "redled123"
